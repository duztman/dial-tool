Dial Tool guide, edition 1 — InDesign package
beta 4.41.24 · made 2026-10-16 by guide/look/build.mjs

  Dial-Tool-guide.idml   8 pages, A4 landscape. Open it in InDesign, then File › Save As… .indd.
  Links/                 the pictures: interface crops (PNG, 3 pixels a point) and the dials (PDF, vector).
  Document fonts/        Inter Regular, Light and SemiBold (OFL). InDesign turns these on for this document.
  guide.pdf              the pages as the build set them, to compare.

What is the same as the PDF: every frame's place and size, the 12 × 14 grid (margins and columns; the rows are
guides), the colours (swatches named "Guide" and the hex code), the paragraph styles (Title, Lead, Body, Label, Caption, …),
the text (live), the lines and outlines (live), the crops and their scale.

What differs: InDesign breaks lines with its own measure, so a few lines can break elsewhere (the styles use the
single-line composer, which is closest to a browser's). The fades at the bottom of two crops (page 03) are hard
edges here. Drop shadows on the cards are InDesign effects. The exploded dial on page 01 is one placed PDF
(stack-01.pdf), not live shapes.

If the pictures show as missing: Links panel › select all › Relink to Folder… › this Links folder.

How changes come back: this is a drafting table, not the source. Move, resize, restyle what you like, then send
the .idml (or the .indd) or screenshots; Claude carries the changes into guide/look/build.mjs, so the next build
from the app keeps them. Words you change here are carried into guide/text/edition-1.md the same way.
